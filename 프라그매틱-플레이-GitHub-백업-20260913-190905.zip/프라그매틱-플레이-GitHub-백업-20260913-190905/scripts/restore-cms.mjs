import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';

// Default: compare only. --apply restores the saved custom content fields.
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const args=new Set(process.argv.slice(2));
if([...args].some(a=>!['--apply','--validate'].includes(a))||args.size>1)throw Error('Usage: node scripts/restore-cms.mjs [--validate | --apply]');
const read=async file=>JSON.parse(await fs.readFile(path.join(root,file),'utf8'));
const [config,settings,rows,schema]=await Promise.all(['wix.config.json','cms/site-settings.json','cms/PageContent.json','cms/PageContent.schema.json'].map(read));
const fields=['key','title','page','kind','text','href','image','icon','visible','newTab'];
if(!config.siteId||config.siteId!==settings.siteId)throw Error('Site ID differs from this backup. This tool restores only the original site.');
if(schema.collection?.id!=='PageContent'||!Array.isArray(rows)||!rows.length)throw Error('Invalid CMS backup');
if(new Set(rows.map(r=>r.key)).size!==rows.length)throw Error('Duplicate backup keys');
for(const row of rows){
 if(!row.key||fields.some(f=>typeof row[f]!==(['visible','newTab'].includes(f)?'boolean':'string')))throw Error('Invalid row: '+row.key);
 if(Object.keys(row).some(f=>!fields.includes(f)))throw Error('Unexpected backup field');
}
if(args.has('--validate')){
 console.log(JSON.stringify({valid:true,items:rows.length,siteId:config.siteId,remoteContacted:false},null,2));
 process.exit(0);
}
let token;
try{
 token=execFileSync(process.execPath,[path.join(root,'node_modules/@wix/cli/bin/wix.cjs'),'token','--site',config.siteId],{cwd:root,encoding:'utf8',windowsHide:true,stdio:['ignore','pipe','pipe']}).trim();
}catch{throw Error('Wix authentication unavailable. Run npm ci --legacy-peer-deps and npx wix login first.');}
if(!token)throw Error('Wix returned no access token');
async function api(route,method='GET',body){
 const response=await fetch('https://www.wixapis.com'+route,{method,headers:{Authorization:'Bearer '+token,'wix-site-id':config.siteId,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(60000)});
 const result=await response.json();
 if(!response.ok){const error=new Error('Wix request failed: '+method+' '+route+' HTTP '+response.status);error.status=response.status;throw error;}
 return result;
}
async function query(){
 const items=[];
 for(let offset=0;;offset+=100){
  const result=await api('/wix-data/v2/items/query','POST',{dataCollectionId:'PageContent',consistentRead:true,query:{paging:{limit:100,offset}}});
  if(!Array.isArray(result.dataItems))throw Error('Invalid CMS response');
  items.push(...result.dataItems);if(result.dataItems.length<100)return items;
 }
}
let missingCollection=false;
try{await api('/wix-data/v2/collections/PageContent');}catch(error){if(error.status!==404)throw error;missingCollection=true;}
const current=missingCollection?[]:await query();
const currentByKey=new Map();
for(const item of current){
 const key=item.data?.key;if(!key)continue;
 if(currentByKey.has(key))throw Error('Duplicate key in live CMS: '+key);
 currentByKey.set(key,item);
}
const normal=(value,field)=>value??(field==='visible'?true:field==='newTab'?false:'');
const changed=(data,row)=>fields.filter(field=>normal(data?.[field],field)!==row[field]);
const inserts=rows.filter(row=>!currentByKey.has(row.key));
const updates=rows.filter(row=>currentByKey.has(row.key)&&changed(currentByKey.get(row.key).data,row).length);
console.log(JSON.stringify({mode:args.has('--apply')?'apply':'compare-only',siteId:config.siteId,createCollection:missingCollection,insert:inserts.length,update:updates.length,unchanged:rows.length-inserts.length-updates.length,delete:0},null,2));
if(!args.has('--apply')){
 console.log('No changes made. To restore the saved values, run: node scripts/restore-cms.mjs --apply');
 process.exit(0);
}
if(missingCollection)await api('/wix-data/v2/collections','POST',schema);
for(const row of updates){
 const item=currentByKey.get(row.key);
 await api('/wix-data/v2/items/'+encodeURIComponent(item.id),'PATCH',{dataCollectionId:'PageContent',patch:{dataItemId:item.id,fieldModifications:changed(item.data,row).map(fieldPath=>({fieldPath,action:'SET_FIELD',setFieldOptions:{value:row[fieldPath]}}))}});
}
for(let offset=0;offset<inserts.length;offset+=50){
 const result=await api('/wix-data/v2/bulk/items/insert','POST',{dataCollectionId:'PageContent',dataItems:inserts.slice(offset,offset+50).map(data=>({data})),returnEntity:true});
 if(result.bulkActionMetadata?.totalFailures||result.results?.some(r=>r.itemMetadata?.success===false))throw Error('CMS insert failed; check Wix CMS and rerun comparison.');
}
const verified=new Map((await query()).map(item=>[item.data.key,item.data]));
for(const row of rows)if(!verified.has(row.key)||changed(verified.get(row.key),row).length)throw Error('Verification failed: '+row.key);
console.log('Restored and verified '+rows.length+' content items. No extra live items were deleted.');
