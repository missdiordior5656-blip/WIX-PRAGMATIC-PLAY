# 프라그매틱 플레이 가이드 — GitHub 백업

2026년 9월 13일 기준 소스, 이미지와 Wix CMS 콘텐츠를 정리한 백업입니다. 정확한 추출 시각과 개수는 `docs/백업범위.json`에 있습니다.

- [공개 사이트](https://pragmatic-play-guide-missdiordior5656-1410.wix-site-host.com/)
- [Wix 대시보드](https://manage.wix.com/dashboard/9ff12c75-cafe-4113-a492-e5e5d8d16efe)

## 포함된 내용

- 홈, 회사 소개(`/about`), FAQ(`/faq`), 라이브 카지노(`/live-casino`)의 전체 소스
- CMS 콘텐츠 276개와 컬렉션 구조, CSV 사본
- 모든 로컬 이미지와 현재 CMS 이미지의 로컬 사본·대응표
- 최신 버튼 문구: 슬롯 4개 **슬롯 플레이하기**, 라이브 10개 **플레이하러 가기**
- 편집 안내, 복원 안내, CMS 비교·복원 스크립트
- 설치 버전을 보관한 `package-lock.json` 및 파일별 SHA-256 목록

버튼 연결 주소도 CMS에 보관되어 있습니다. 이 백업을 만드는 과정에서 공개 사이트를 수정하지 않았습니다.

## GitHub에 보관하기

1. ZIP의 압축을 풉니다.
2. GitHub 저장소에 이 폴더 **안의 파일과 폴더**를 올립니다. 최상위에 `README.md`, `package.json`, `src`, `public`, `cms`가 보이면 됩니다.
3. `.gitignore`도 함께 올립니다. 원본 ZIP을 추가 보관해도 됩니다.

로그인 토큰과 `.env` 파일, `node_modules`, 설치 캐시, 빌드 결과는 포함하지 않았습니다. 이후 개발할 때도 해당 파일은 GitHub에 올리지 않습니다.

## 파일 위치

| 위치 | 내용 |
|---|---|
| `src/` | 페이지, 컴포넌트, 스타일, SEO, CMS 연결 코드 |
| `public/` | 이미지와 사이트 아이콘 |
| `src/data/content.json` | 백업 시점 CMS 내용으로 갱신한 기본 데이터. 이미지 경로는 로컬 사본 사용 |
| `cms/PageContent.json` | CMS 복원용 데이터. Wix 이미지 주소 유지 |
| `cms/PageContent.csv` | 스프레드시트에서 열 수 있는 UTF-8 CSV |
| `cms/PageContent.schema.json` | CMS 필드와 권한 설정 |
| `cms/media-manifest.json` | CMS 이미지 주소, 로컬 파일, 원자료 주소, 해시 |
| `docs/편집안내.md` | Wix에서 문구·이미지·링크 수정하기 |
| `docs/복원안내.md` | 설치, CMS 복원, 재배포 순서 |
| `scripts/restore-cms.mjs` | 기본 실행은 비교만 수행. `--apply`로 저장된 내용 복원 |
| `BACKUP-MANIFEST.json` | 백업 파일의 크기와 SHA-256 |

## 다시 실행할 때

Node.js 24 환경에서 작업했습니다. 프로젝트 폴더에서 다음 순서로 진행합니다.

```sh
npm ci --legacy-peer-deps
npx wix login
npx wix env pull
npm run build
```

빌드 후 실제 공개 사이트를 배포하려면 `npm run release`를 실행합니다. CMS 복원은 필요할 때만 별도로 진행하며 [복원 안내](docs/복원안내.md)를 참고하세요.

Wix Managed Headless/Astro 프로젝트이므로 HTML 파일을 더블클릭하는 방식으로 실행하지 않습니다. Wix 계정 연결과 실행 환경을 다시 준비해야 합니다. 도메인·프리미엄 결제·계정 로그인·검색 도구 소유권은 ZIP에 포함되는 대상이 아니며 기존 계정에서 관리됩니다.
