/**
 * Server-only helper for an Astro SSR page using the wix() integration.
 * PageContent permissions: read ANYONE; insert/update/remove ADMIN only.
 * Invoke inside Astro frontmatter per request, never at module top level.
 * Wix's auth middleware supplies visitor OAuth automatically; no admin key.
 */
import * as items from '@wix/wix-data-items-sdk';
import { media } from '@wix/sdk';

export type CmsRow = Record<string, unknown> & { _id?: string };

/** TEXT is rendered through normal Astro {expressions}, never set:html. */
export function cmsText(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value : fallback;
}

/** Supports Wix CMS IMAGE values and ordinary HTTPS image URLs. */
export function cmsImage(value: unknown, fallback = ''): string {
  const source = typeof value === 'string'
    ? value
    : value && typeof value === 'object' && 'src' in value
      ? cmsText(value.src)
      : '';
  if (!source) return fallback;
  if (source.startsWith('/') && !source.startsWith('//') && !source.includes('\\')) return source;
  try {
    if (source.startsWith('wix:image://')) return media.getImageUrl(source).url;
    const url = new URL(source);
    return url.protocol === 'https:' ? url.href : fallback;
  } catch {
    return fallback;
  }
}

/**
 * Returns SDK items (custom fields are directly on row, not row.data).
 * Schema-neutral: caller selects the actual seeded fields by name.
 * No module cache: CMS edits are fetched on each page request.
 */
export async function readPageContent(): Promise<CmsRow[] | null> {
  try {
    let result = await items.query('PageContent').limit(1000).find({ consistentRead: true });
    const rows: CmsRow[] = [...result.items];
    while (result.hasNext()) {
      result = await result.next();
      rows.push(...result.items);
    }
    return rows;
  } catch (error) {
    console.error('[CMS PageContent] Public read failed', error instanceof Error ? error.message : 'Unknown error');
    // The page should render its authored fallback content if CMS is unavailable.
    return null;
  }
}
