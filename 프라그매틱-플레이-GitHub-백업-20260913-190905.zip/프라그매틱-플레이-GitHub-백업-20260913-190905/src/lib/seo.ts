import type { PageContent } from './content';
export const siteOrigin='https://pragmatic-play-guide-missdiordior5656-1410.wix-site-host.com';
export function pageSeo(content:PageContent,path='/'){
 const canonical=new URL(path,siteOrigin).href;
 const title=content.text(path==='/live-casino'?'seo.liveTitle':path==='/about'?'seo.aboutTitle':path==='/faq'?'seo.faqTitle':'seo.title');
 const description=content.text(path==='/live-casino'?'seo.liveDescription':path==='/about'?'seo.aboutDescription':path==='/faq'?'seo.faqDescription':'seo.description');
 const siteName=content.text('seo.siteName');
 const imageKey=path==='/live-casino'?'livepage.hero.image':'hero.image';
 const image=content.image(imageKey)?new URL(content.image(imageKey),siteOrigin).href:'';
 const graph:Record<string,unknown>[]=[{'@type':'WebSite','@id':siteOrigin+'/#website',url:siteOrigin+'/',name:siteName,inLanguage:'ko'},{'@type':'WebPage','@id':canonical+'#webpage',url:canonical,name:title,description,inLanguage:'ko',isPartOf:{'@id':siteOrigin+'/#website'}}];
 if(path==='/faq')graph.push({'@type':'FAQPage','@id':canonical+'#faq',mainEntity:['1','2','3','4','5'].filter(i=>content.text(`faq.${i}.question`)&&content.text(`faq.${i}.answer`)).map(i=>({'@type':'Question',name:content.text(`faq.${i}.question`),acceptedAnswer:{'@type':'Answer',text:content.text(`faq.${i}.answer`)}}))});
 if(path==='/live-casino')graph.push({'@type':'FAQPage','@id':canonical+'#faq',mainEntity:['1','2','3','4'].filter(i=>content.text(`livepage.faq.${i}.question`)&&content.text(`livepage.faq.${i}.answer`)).map(i=>({'@type':'Question',name:content.text(`livepage.faq.${i}.question`),acceptedAnswer:{'@type':'Answer',text:content.text(`livepage.faq.${i}.answer`)}}))});
 return {title,description,siteName,canonical,image,imageAlt:content.text(imageKey),icon:content.image('brand.favicon'),jsonLd:JSON.stringify({'@context':'https://schema.org','@graph':graph}).replace(/</g,'\\u003c')};
}
