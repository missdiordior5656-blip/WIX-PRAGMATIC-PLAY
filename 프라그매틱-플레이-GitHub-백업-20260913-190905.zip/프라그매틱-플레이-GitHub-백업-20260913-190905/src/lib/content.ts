import fallbackRows from '../data/content.json';
import { readPageContent, cmsImage, cmsText, type CmsRow } from './cms';

export type ContentRow = {
  key: string;
  title: string;
  page: string;
  kind: string;
  text: string;
  href: string;
  image: string;
  icon: string;
  visible: boolean;
  newTab: boolean;
};

export function safeHref(value: unknown): string {
  const href = cmsText(value).trim();
  if (!href || /[\u0000-\u001f\u007f\\]/.test(href)) return '';
  if (href.startsWith('#')) return href;
  if (href.startsWith('/') && !href.startsWith('//')) return href;
  try {
    const parsed = new URL(href);
    return parsed.protocol === 'https:' ? parsed.href : '';
  } catch { return ''; }
}

export function contentFromRows(rows: CmsRow[]) {
  const byKey = new Map<string, ContentRow>();
  for (const raw of rows) {
    const key = cmsText(raw.key);
    if (!key || cmsText(raw.page) !== 'home' || raw.visible === false) continue;
    byKey.set(key, {
      key, title: cmsText(raw.title), page: 'home', kind: cmsText(raw.kind),
      text: cmsText(raw.text), href: safeHref(raw.href), image: cmsImage(raw.image),
      icon: cmsText(raw.icon), visible: true, newTab: raw.newTab === true,
    });
  }
  return {
    row: (key: string) => byKey.get(key),
    text: (key: string) => byKey.get(key)?.text ?? '',
    image: (key: string) => byKey.get(key)?.image ?? '',
    has: (key: string) => byKey.has(key),
    hasPrefix: (prefix: string) => [...byKey.keys()].some(key => key.startsWith(prefix)),
    link: (key: string) => {
      const row = byKey.get(key);
      return row?.href && row.text ? row : undefined;
    },
  };
}

export type PageContent = ReturnType<typeof contentFromRows>;

export async function loadContent(): Promise<PageContent> {
  const rows = await readPageContent();
  // Only an unavailable CMS uses the authored content. An empty or edited
  // collection remains authoritative, including deliberately deleted rows.
  return contentFromRows(rows === null ? fallbackRows : rows);
}
