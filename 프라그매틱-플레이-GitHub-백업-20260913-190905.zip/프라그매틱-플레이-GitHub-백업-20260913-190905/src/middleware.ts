import { defineMiddleware } from 'astro:middleware';
import { seoHeadTransform } from './lib/seo-head.mjs';

const pages = new Set(['/', '/about', '/faq', '/live-casino']);
export const onRequest = defineMiddleware(async ({url}, next) => {
  const response = await next();
  if (!pages.has(url.pathname.replace(/\/$/, '') || '/') || response.status !== 200 ||
      !response.headers.get('content-type')?.includes('text/html') || !response.body) return response;
  const headers = new Headers(response.headers);
  headers.delete('content-length');
  headers.delete('etag');
  return new Response(response.body.pipeThrough(new TextDecoderStream())
    .pipeThrough(seoHeadTransform()).pipeThrough(new TextEncoderStream()),
    {status: response.status, statusText: response.statusText, headers});
});
