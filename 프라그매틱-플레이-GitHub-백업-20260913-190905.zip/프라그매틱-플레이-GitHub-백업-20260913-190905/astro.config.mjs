// @ts-check
import { defineConfig } from 'astro/config';
import wix from "@wix/astro";
import wixPages from "@wix/astro-pages";

import wixHostingAdapter from "@wix/astro-wix-hosting-adapter";
import tailwindcss from "@tailwindcss/vite";

// https://astro.build/config
export default defineConfig({
  site: 'https://pragmatic-play-guide-missdiordior5656-1410.wix-site-host.com',
  integrations: [wix(), wixPages()],

  adapter: wixHostingAdapter(),

  image: {
    domains: ["static.wixstatic.com"],
  },

  vite: {
    plugins: [tailwindcss()],
    optimizeDeps: { disabled: true, noDiscovery: true, include: [], exclude: ["aria-query", "axobject-query"] },
    ssr: { external: ["aria-query", "axobject-query"] },
  },

  output: "server",
});
