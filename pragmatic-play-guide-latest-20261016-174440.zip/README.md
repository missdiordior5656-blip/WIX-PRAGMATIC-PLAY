# 프라그매틱 플레이 가이드 — 최신 소스 및 CMS 백업

백업 생성: 20261016-174440 (한국 시간). CMS 추출 시각: 2026-10-16T08:43:32.144Z (UTC).
운영 주소: https://www.alphaxpragmatic.com/
Wix 사이트 ID: `9ff12c75-cafe-4113-a492-e5e5d8d16efe`

2026-10-16 배포한 소스를 기준으로, 백업 시점의 최신 CMS 279개 항목을 함께 보관했습니다.
HOME, `/about`, `/faq`, `/live-casino` 모두 우측 하단 X · Instagram · Telegram 아이콘을 사용합니다.
CMS에서 사용자가 입력한 실제 링크와 최신 문구도 포함됩니다. 기본 콘텐츠 JSON도 최신 CMS 값으로 갱신했습니다.

## GitHub에 보관

ZIP을 풀고 **이 폴더 안의 파일과 폴더 전체**를 저장소 루트에 올립니다.
루트에 `README.md`, `package.json`, `src/`, `public/`, `cms/`, `.gitignore`가 보여야 합니다.
환경변수, 로그인 토큰, `.wix`, `node_modules`, 빌드 결과는 제외했습니다.
CMS에 설정한 공개 링크와 문구가 들어 있으므로 공개 저장소에 올리기 전에 내용을 확인하세요.

## 다음에 실행·수정·배포

Node.js 24와 npm이 설치된 환경에서 실행합니다. 검증에 사용한 설치 잠금 파일은 `pnpm-lock.yaml`입니다.

```sh
npm install -g pnpm@11.25.0
pnpm install --frozen-lockfile
npx wix login
npx wix env pull
node scripts/restore-cms.mjs --validate
npm run test:seo
npm run build
```

기존 사이트에 수정 코드를 게시하려면 빌드 성공 후 `npm run release`를 실행합니다.
Wix 로그인과 환경변수는 해당 계정에서 다시 준비해야 합니다.
기존 사이트·앱 ID는 `wix.config.json`에 보관했습니다. 새 사이트를 만들 필요가 없습니다.
이 파일들은 Astro 서버 프로젝트이므로 정적 HTML 업로드 방식으로 배포하지 않습니다.

## CMS 복원은 필요한 경우에만

운영 CMS가 정상이라면 복원하지 않습니다. 소스는 운영 CMS의 현재 값을 읽습니다.

```sh
node scripts/restore-cms.mjs
```

위 명령은 비교만 수행합니다. 이 백업의 값으로 되돌릴 의도가 있을 때만 다음을 실행합니다.

```sh
node scripts/restore-cms.mjs --apply
```

복원은 저장된 문구·주소·이미지·표시 설정을 반영하므로 백업 이후 편집한 값이 바뀔 수 있습니다.
추가로 존재하는 운영 항목은 삭제하지 않습니다. 다른 사이트로의 이전은 별도 설정이 필요합니다.
현재 CMS를 다시 추출하려면 프로젝트 루트에서 `node scripts/export-cms.mjs`를 실행합니다.
이미지 사본도 새로 받으려면 `node scripts/archive-current-media.mjs`를 이어서 실행합니다.

## 소셜 아이콘 링크 편집

CMS **프라그매틱 사이트 편집 (PageContent)**에서 `footer.social.x`,
`footer.social.instagram`, `footer.social.telegram` 항목의 `href`에 HTTPS 주소를 넣습니다.
`visible`로 숨기거나 표시할 수 있으며 `newTab`으로 새 창 여부를 정합니다.
한 번 수정하면 네 페이지 모두에 적용됩니다. `key`와 `page: home`은 유지하세요.

## 포함 파일

- `src/`: 최신 공통 푸터, 소셜 아이콘, 전체 페이지·CMS·SEO 코드
- `public/`: 기존 로컬 이미지와 사이트 아이콘
- `cms/PageContent.json`, `.csv`: 최신 CMS 279개 항목
- `cms/PageContent.schema.json`: 복원용 컬렉션 구조와 권한
- `cms/PageContent.schema.raw.json`: 현재 컬렉션의 전체 응답 보관본
- `cms/media-current/`, `media-current-manifest.json`: 현재 CMS 이미지 15개와 원본 주소·해시
- `cms/export-info.json`: 실제 CMS 추출 시각
- `pnpm-lock.yaml`, `pnpm-workspace.yaml`: 설치 버전과 Wix 빌드용 패키지 배치 설정
- `BACKUP-MANIFEST.json`: 파일별 SHA-256 무결성 목록
- `docs/history-20260914/`: 이전 버전 안내·기존 npm 잠금 파일. 현재 설치·복원은 이 README를 따릅니다.

소셜 아이콘 추가 버전의 빌드·게시 및 네 페이지 응답을 확인했고, 최신 CMS 스냅샷 구조와 SEO 검사 10개를 통과했습니다.
소스와 CMS, 이미지가 백업 대상입니다. Wix 계정, 결제, 도메인 DNS, 검색 도구 소유권, 과거 CMS 버전 기록은 포함되지 않습니다.
