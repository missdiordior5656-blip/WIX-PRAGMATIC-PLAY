import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
const rows = JSON.parse(await fs.readFile('cms/PageContent.json', 'utf8'));
const sources = [...new Set(rows.map(r => r.image).filter(Boolean))];
await fs.mkdir('cms/media-current', { recursive: true });
const records = [];
for (let i = 0; i < sources.length; i++) {
  const source = sources[i];
  const url = source.startsWith('wix:image://v1/') ? 'https://static.wixstatic.com/media/' + source.slice('wix:image://v1/'.length).split('/')[0] : source;
  if (!/^https:\/\//.test(url)) throw Error('Unsupported image: ' + source);
  const r = await fetch(url, { signal: AbortSignal.timeout(60000) });
  if (!r.ok) throw Error('Image download failed: HTTP ' + r.status);
  const bytes = Buffer.from(await r.arrayBuffer());
  const mime = r.headers.get('content-type')?.split(';')[0];
  const ext = ({'image/png':'.png','image/jpeg':'.jpg','image/webp':'.webp','image/svg+xml':'.svg','image/gif':'.gif'})[mime];
  if (!ext) throw Error('Unexpected image MIME: ' + mime);
  const file = `cms/media-current/image-${String(i+1).padStart(2,'0')}${ext}`;
  await fs.writeFile(file, bytes);
  records.push({ source, url, file, mime, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
}
await fs.writeFile('cms/media-current-manifest.json', JSON.stringify(records, null, 2) + '\n');
console.log(JSON.stringify({ archivedImages: records.length }));
