import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const config = JSON.parse(await fs.readFile(path.join(root, 'wix.config.json'), 'utf8'));
if (config.siteId !== '9ff12c75-cafe-4113-a492-e5e5d8d16efe') throw Error('Site identity mismatch');
let token;
try {
  token = execFileSync(process.execPath, [path.join(root, 'node_modules/@wix/cli/bin/wix.cjs'), 'token', '--site', config.siteId], { cwd: root, encoding: 'utf8', windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }).trim();
} catch { throw Error('Wix authentication unavailable. Run npx wix login first.'); }
async function api(route, method = 'GET', body) {
  const r = await fetch('https://www.wixapis.com' + route, { method, headers: { Authorization: `Bearer ${token}`, 'wix-site-id': config.siteId, 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(60000) });
  if (!r.ok) throw Error(`${method} ${route}: HTTP ${r.status}`);
  return r.json();
}
const items = [];
for (let offset = 0; ; offset += 100) {
  const r = await api('/wix-data/v2/items/query', 'POST', { dataCollectionId: 'PageContent', consistentRead: true, query: { paging: { limit: 100, offset } } });
  if (!Array.isArray(r.dataItems)) throw Error('Unexpected CMS response');
  items.push(...r.dataItems);
  if (r.dataItems.length < 100) break;
}
const schema = await api('/wix-data/v2/collections/PageContent');
const fields = ['key','title','page','kind','text','href','image','icon','visible','newTab'];
const rows = items.map(item => Object.fromEntries(fields.map(f => [f, item.data[f] ?? (f === 'visible' ? true : f === 'newTab' ? false : '')]))).sort((a,b) => a.key.localeCompare(b.key));
if (new Set(rows.map(r => r.key)).size !== rows.length) throw Error('Duplicate content keys');
const dir = path.join(root, 'cms');
await fs.mkdir(dir, { recursive: true });
await fs.writeFile(path.join(dir, 'PageContent.json'), JSON.stringify(rows, null, 2) + '\n');
const q = v => '"' + String(v).replaceAll('"', '""') + '"';
await fs.writeFile(path.join(dir, 'PageContent.csv'), '\uFEFF' + [fields.map(q).join(','), ...rows.map(r => fields.map(f => q(r[f])).join(','))].join('\r\n') + '\r\n');
await fs.writeFile(path.join(dir, 'PageContent.schema.raw.json'), JSON.stringify(schema, null, 2) + '\n');
const collection = schema.collection;
const restoreSchema = { collection: {
  id: collection.id, displayName: collection.displayName, displayField: collection.displayField,
  fields: collection.fields.filter(f => !f.key.startsWith('_')).map(f => ({ key: f.key, displayName: f.displayName, type: f.type })),
  permissions: collection.permissions,
} };
await fs.writeFile(path.join(dir, 'PageContent.schema.json'), JSON.stringify(restoreSchema, null, 2) + '\n');
await fs.writeFile(path.join(dir, 'export-info.json'), JSON.stringify({ exportedAt: new Date().toISOString(), siteId: config.siteId, items: rows.length, fields, collectionId: 'PageContent' }, null, 2) + '\n');
await fs.writeFile(path.join(root, 'src/data/content.json'), JSON.stringify(rows, null, 2) + '\n');
console.log(JSON.stringify({ exported: rows.length, collection: 'PageContent', credentialsSaved: false }));
