import fs from 'node:fs/promises';
const rows = ['X', 'Instagram', 'Telegram'].map(name => ({
  key: `footer.social.${name.toLowerCase()}`,
  title: `모든 페이지 · 우측 하단 · ${name}`,
  page: 'home', kind: 'link', text: name, href: '', image: '',
  icon: name.toLowerCase(), visible: true, newTab: true,
}));
await fs.writeFile('cms/social-links.json', JSON.stringify(rows, null, 2));
const file = 'src/data/content.json';
const data = JSON.parse(await fs.readFile(file, 'utf8'));
for (const row of rows) if (!data.some(x => x.key === row.key)) data.push(row);
await fs.writeFile(file, JSON.stringify(data, null, 2) + '\n');
