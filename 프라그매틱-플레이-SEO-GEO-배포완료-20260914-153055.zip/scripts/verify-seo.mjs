import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { siteOrigin, pageDefinitions, canonicalUrl } from '../src/lib/site.mjs';

const args = process.argv.slice(2);
const base = args.find(arg => arg.startsWith('--base='))?.slice(7) || siteOrigin;
const pagesOnly = args.includes('--pages-only');
if (args.some(arg => arg !== '--pages-only' && !arg.startsWith('--base='))) throw new Error('Usage: node scripts/verify-seo.mjs [--base=https://preview.example] [--pages-only]');
const rows = JSON.parse(await fs.readFile(new URL('../src/data/content.json', import.meta.url), 'utf8'));
const content = new Map(rows.map(row => [row.key, row.text]));
const decode = value => value.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');
const attributes = tag => Object.fromEntries([...tag.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)]
  .map(([, name, double, single]) => [name.toLowerCase(), decode(double ?? single)]));
async function get(path) {
  const response = await fetch(new URL(path, base), { signal: AbortSignal.timeout(45000), headers: { 'Cache-Control': 'no-cache' } });
  assert.equal(response.status, 200, `${path}: HTTP ${response.status}`);
  assert.doesNotMatch(response.headers.get('x-robots-tag') || '', /noindex|none/i, `${path}: X-Robots-Tag blocks indexing`);
  return { response, body: await response.text() };
}

const report = { base, checkedAt: new Date().toISOString(), pages: [], discovery: {} };
for (const [path, definition] of Object.entries(pageDefinitions)) {
  const { response, body } = await get(path);
  assert.match(response.headers.get('content-type') || '', /text\/html/i);
  const head = body.split(/<\/head\s*>/i)[0];
  const titles = [...head.matchAll(/<title\b[^>]*>([\s\S]*?)<\/title\s*>/gi)];
  assert.equal(titles.length, 1, `${path}: exactly one title`);
  const title = decode(titles[0][1]);
  assert.equal(title, content.get(definition.titleKey), `${path}: live title differs from reviewed content`);
  const tags = [...head.matchAll(/<(?:meta|link)\b[^>]*>/gi)].map(match => attributes(match[0]));
  const single = predicate => { const matches = tags.filter(predicate); assert.equal(matches.length, 1); return matches[0]; };
  const canonical = single(tag => tag.rel === 'canonical').href;
  assert.equal(canonical, canonicalUrl(path), `${path}: canonical`);
  const description = single(tag => tag.name === 'description').content;
  assert.equal(description, content.get(definition.descriptionKey), `${path}: description`);
  assert.ok([...description].length >= 120 && [...description].length <= 150);
  assert.equal(single(tag => tag.property === 'og:url').content, canonical);
  assert.equal(single(tag => tag.property === 'og:title').content, title);
  assert.equal(single(tag => tag.name === 'twitter:description').content, description);
  for (const tag of tags.filter(tag => /^(robots|googlebot|bingbot)$/i.test(tag.name || ''))) assert.doesNotMatch(tag.content || '', /noindex|none/i);
  const jsonLd = [...head.matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)]
    .map(match => JSON.parse(match[1]));
  const graph = jsonLd.flatMap(value => value['@graph'] || [value]);
  const page = graph.find(node => node['@id'] === `${canonical}#webpage`);
  assert.ok(page, `${path}: page linked data`);
  assert.equal(page.url, canonical);
  assert.doesNotMatch(JSON.stringify(page), /wix-site-host\.com/);
  assert.equal([...body.matchAll(/<h1\b/gi)].length, 1, `${path}: H1`);
  if (path === '/') assert.match(body, /프라그매틱 플레이,/);
  if (path !== '/') assert.ok(body.includes('aria-label="현재 페이지 위치"'), `${path}: visible breadcrumbs`);
  assert.ok(body.includes('함께 읽을 가이드'), `${path}: related guide links`);
  report.pages.push({ path, title, description, descriptionCharacters: [...description].length, canonical, jsonLdValid: true });
}
assert.equal(new Set(report.pages.map(page => page.title)).size, report.pages.length);

if (!pagesOnly) {
  const { body: robots } = await get('/robots.txt');
  assert.ok(robots.includes(`Sitemap: ${siteOrigin}/sitemap.xml`));
  const { body: sitemap } = await get('/sitemap.xml');
  assert.ok(sitemap.includes(`${siteOrigin}/pages-sitemap.xml`));
  const { body: pageSitemap } = await get('/pages-sitemap.xml');
  const sitemapUrls = [...pageSitemap.matchAll(/<loc>(.*?)<\/loc>/g)].map(match => decode(match[1]).replace(/\/$/, ''));
  for (const path of Object.keys(pageDefinitions)) assert.ok(sitemapUrls.includes(canonicalUrl(path).replace(/\/$/, '')), `${path}: sitemap entry`);
  const { body: llms } = await get('/llms.txt');
  assert.ok(llms.includes('## Korean independent guide: site scope'), 'llms.txt guide description');
  for (const path of Object.keys(pageDefinitions)) assert.ok(llms.includes(canonicalUrl(path)), `${path}: llms.txt link`);
  report.discovery = { robotsSitemapReference: true, robotsRulesRequireReview: true, sitemap: true, sitemapPages: sitemapUrls.length, llms: true };
}
await fs.mkdir(new URL('../.wix/', import.meta.url), { recursive: true });
await fs.writeFile(new URL('../.wix/seo-verification.json', import.meta.url), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
