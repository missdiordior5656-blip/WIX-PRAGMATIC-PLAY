import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

// Narrow, idempotent update; never restores the whole archived CMS collection.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
if (args.some(arg => !['--apply'].includes(arg))) throw new Error('Usage: node scripts/update-seo.mjs [--apply]');
const apply = args.includes('--apply');
const read = async file => JSON.parse(await fs.readFile(path.join(root, file), 'utf8'));
const config = await read('wix.config.json');
const plan = await read('cms/seo-content-update.json');
if (config.siteId !== plan.siteId || plan.siteId !== '9ff12c75-cafe-4113-a492-e5e5d8d16efe') throw new Error('Site identity mismatch');
let token;
try {
  token = execFileSync(process.execPath, [path.join(root, 'node_modules/@wix/cli/bin/wix.cjs'),
    'token', '--site', config.siteId], { cwd: root, encoding: 'utf8', windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'] }).trim();
} catch {
  // Never expose captured CLI stdout/stderr, which may contain authentication data.
  throw new Error('Wix authentication unavailable; complete wix login before retrying.');
}
if (!token) throw new Error('Wix authentication unavailable');

async function api(route, method = 'GET', body) {
  const response = await fetch(`https://www.wixapis.com${route}`, {
    method, headers: { Authorization: `Bearer ${token}`, 'wix-site-id': config.siteId, 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(60000),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(`Wix ${method} ${route}: HTTP ${response.status}; ${JSON.stringify(result.details ?? result.message ?? {})}`);
  return result;
}

const rows = [];
for (let offset = 0; ; offset += 100) {
  const result = await api('/wix-data/v2/items/query', 'POST', {
    dataCollectionId: 'PageContent', consistentRead: true, query: { paging: { limit: 100, offset } },
  });
  if (!Array.isArray(result.dataItems)) throw new Error('Unexpected CMS response');
  rows.push(...result.dataItems);
  if (result.dataItems.length < 100) break;
}

const pending = [];
for (const change of plan.changes) {
  const matches = rows.filter(item => item.data?.key === change.key);
  if (matches.length !== 1) throw new Error(`Expected one CMS row for ${change.key}; found ${matches.length}`);
  const item = matches[0];
  if (item.data.visible === false || item.data.page !== 'home') throw new Error(`CMS field hidden or moved: ${change.key}`);
  if (item.data.text === change.text) continue;
  if (item.data.text !== change.expectedText) throw new Error(`CMS text changed since backup; review before replacing ${change.key}`);
  pending.push({ id: item.id, key: change.key, beforeText: item.data.text, text: change.text });
}

// This managed endpoint remains owned by Wix; add guide information to its
// existing content rather than shadowing robots/sitemap/llms in public/.
const llmsRoute = '/promote-seo-robots-server/v2/llms';
const llms = (await api(`${llmsRoute}?subdomain=www`)).llmsTxt;
if (!llms || typeof llms.content !== 'string' || llms.hidden) throw new Error('Expected existing public llms.txt; no visibility change will be made');
const addition = await fs.readFile(path.join(root, 'cms/llms-guide-addendum.md'), 'utf8');
const marker = '## Korean independent guide: site scope';
// Wix can return an empty stored content while serving a generated public file.
// This site's public default was captured before customization; retain its MCP guide.
const defaultBaseline = await fs.readFile(path.join(root, 'cms/llms-wix-baseline.txt'), 'utf8');
const repairBaseline = llms.content.trim() === addition.trim();
const appendLlms = !llms.content.includes(marker) || repairBaseline;
const baseContent = repairBaseline || (llms.default && !llms.content.trim()) ? defaultBaseline : llms.content;
console.log(JSON.stringify({ mode: apply ? 'apply' : 'check', siteId: config.siteId,
  changedFields: pending.map(item => item.key), llmsAppend: appendLlms, restoreCollection: false }, null, 2));
if (!apply) process.exit(0);

await fs.mkdir(path.join(root, '.wix'), { recursive: true });
const snapshot = path.join(root, '.wix', `seo-before-${Date.now()}.json`);
await fs.writeFile(snapshot, JSON.stringify({ siteId: config.siteId, pending, llms }, null, 2));

// Patch only text. Link destinations, images, visibility and all other rows stay intact.
for (const change of pending) {
  const result = await api(`/wix-data/v2/items/${encodeURIComponent(change.id)}`, 'PATCH', {
    dataCollectionId: 'PageContent', patch: { dataItemId: change.id, fieldModifications: [
      { fieldPath: 'text', action: 'SET_FIELD', setFieldOptions: { value: change.text } },
    ] },
    condition: { filter: { key: change.key, page: 'home', text: change.beforeText, visible: { $ne: false } } },
  });
  if (result.dataItem?.data?.text !== change.text) throw new Error(`CMS write could not be verified: ${change.key}`);
  console.log(`Updated ${change.key}`);
}
if (appendLlms) {
  // Wix's append endpoint returned an empty entity without saving on this site.
  // Preserve the freshly read visible content and use the documented update method.
  const freshLlms = (await api(`${llmsRoute}?subdomain=www`)).llmsTxt;
  if (freshLlms?.content !== llms.content || freshLlms.hidden) throw new Error('llms.txt changed during the update; review before retrying');
  const desiredContent = `${baseContent.trimEnd()}\n\n${addition.trim()}\n`;
  const result = await api(llmsRoute, 'PUT', { llmsTxt: {
    content: desiredContent, default: false, subdomain: 'www', manuallyEdited: true,
  } });
  const savedLlms = (await api(`${llmsRoute}?subdomain=www`)).llmsTxt;
  if (!savedLlms?.content?.includes(marker) || !savedLlms.content.includes(baseContent.trimEnd())) throw new Error(`llms.txt update was not confirmed; default=${savedLlms?.default}, manuallyEdited=${savedLlms?.manuallyEdited}, returnedLength=${result.llmsTxt?.content?.length}`);
  console.log('Updated llms.txt; manual content must be maintained when guide pages change.');
}
console.log(JSON.stringify({ completed: true, updatedCmsFields: pending.length, llmsUpdated: appendLlms, snapshot }, null, 2));
