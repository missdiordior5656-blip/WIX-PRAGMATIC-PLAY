
## Korean independent guide: site scope

프라그매틱 플레이 가이드(https://www.alphaxpragmatic.com/)는 Pragmatic Play의 회사와 제품을 소개하는 한국어 독립 정보 가이드입니다. 제작사의 공식 홈페이지가 아니며, 회사·제품 설명은 아래의 공식 자료를 바탕으로 정리합니다.

## Guide pages

- [프라그매틱 플레이 가이드](https://www.alphaxpragmatic.com/): 회사 개요, 대표 슬롯, 라이브 카지노 제품군 및 관련 공식 자료.
- [회사 소개](https://www.alphaxpragmatic.com/about): B2B 콘텐츠 공급자의 역할, 제품 포트폴리오와 기술 소개.
- [라이브 카지노 가이드](https://www.alphaxpragmatic.com/live-casino): 바카라·블랙잭·룰렛·게임쇼의 특징, 스튜디오와 화면 구성, 관련 FAQ.
- [자주 묻는 질문](https://www.alphaxpragmatic.com/faq): 공식 사이트와 독립 가이드의 차이, 슬롯과 라이브 카지노 비교, 게임 시리즈 구분 및 자료 확인 경로.

## Primary references

- [Pragmatic Play 회사 소개](https://www.pragmaticplay.com/en/about-us/)
- [Pragmatic Play 게임](https://www.pragmaticplay.com/en/games/)
- [Pragmatic Play 라이브 카지노](https://www.pragmaticplay.com/en/live-casino/)

게임명·로고·공식 이미지의 권리는 각 권리자에게 있습니다. 제품별 세부 규칙과 제공 범위는 해당 제품의 공식 안내를 기준으로 확인합니다.
