import type { PageContent } from './content';
import { siteOrigin, pageDefinitions, normalizePagePath, canonicalUrl } from './site.mjs';

export { siteOrigin } from './site.mjs';

function questions(content: PageContent, prefix: string, count: number) {
  return Array.from({ length: count }, (_, i) => String(i + 1))
    .filter(i => content.text(`${prefix}.${i}.question`) && content.text(`${prefix}.${i}.answer`))
    .map(i => ({ '@type': 'Question', name: content.text(`${prefix}.${i}.question`),
      acceptedAnswer: { '@type': 'Answer', text: content.text(`${prefix}.${i}.answer`) } }));
}

export function pageSeo(content: PageContent, path = '/') {
  const normalized = normalizePagePath(path) as keyof typeof pageDefinitions;
  const canonical = canonicalUrl(normalized);
  const definition = pageDefinitions[normalized];
  const title = content.text(definition.titleKey);
  const description = content.text(definition.descriptionKey);
  const siteName = content.text('seo.siteName');
  const imageSource = content.image(definition.imageKey);
  const image = imageSource ? new URL(imageSource, siteOrigin).href : '';
  const imageAlt = content.text(definition.imageKey);
  const websiteId = `${siteOrigin}/#website`;
  const page: Record<string, unknown> = {
    '@type': definition.type, '@id': `${canonical}#webpage`, url: canonical,
    name: title, description, inLanguage: 'ko', isPartOf: { '@id': websiteId },
  };
  const graph: Record<string, unknown>[] = [{
    '@type': 'WebSite', '@id': websiteId, url: `${siteOrigin}/`, name: siteName,
    description: content.text('footer.description'), inLanguage: 'ko',
  }, page];

  // Sources are the same public reference links visible in the page footer.
  const citations = ['source.company', 'source.games', 'source.live']
    .map(key => content.link(key)?.href).filter((href): href is string => !!href && href.startsWith('https://'));
  if (citations.length) page.citation = [...new Set(citations)];

  if (image) {
    const imageId = `${canonical}#primaryimage`;
    page.primaryImageOfPage = { '@id': imageId };
    graph.push({ '@type': 'ImageObject', '@id': imageId, contentUrl: image, caption: imageAlt });
  }

  if (normalized !== '/') {
    const breadcrumbId = `${canonical}#breadcrumb`;
    page.breadcrumb = { '@id': breadcrumbId };
    graph.push({ '@type': 'BreadcrumbList', '@id': breadcrumbId, itemListElement: [
      { '@type': 'ListItem', position: 1, name: siteName, item: `${siteOrigin}/` },
      { '@type': 'ListItem', position: 2, name: definition.label, item: canonical },
    ] });
  }

  if (normalized === '/faq') {
    const mainEntity = questions(content, 'faq', 5);
    if (mainEntity.length) page.mainEntity = mainEntity;
    else page['@type'] = 'WebPage';
  }
  if (normalized === '/live-casino') {
    const mainEntity = questions(content, 'livepage.faq', 4);
    if (mainEntity.length) {
      const faqId = `${canonical}#faq`;
      page.hasPart = { '@id': faqId };
      graph.push({ '@type': 'FAQPage', '@id': faqId, url: faqId, inLanguage: 'ko',
        isPartOf: { '@id': `${canonical}#webpage` }, mainEntity });
    }
  }

  return { title, description, siteName, canonical, image, imageAlt,
    icon: content.image('brand.favicon'),
    jsonLd: JSON.stringify({ '@context': 'https://schema.org', '@graph': graph }).replace(/</g, '\\u003c'),
  };
}
