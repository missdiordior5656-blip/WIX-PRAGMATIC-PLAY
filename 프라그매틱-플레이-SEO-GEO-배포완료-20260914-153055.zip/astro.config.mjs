// @ts-check
import { defineConfig } from 'astro/config';
import wix from "@wix/astro";
import wixPages from "@wix/astro-pages";

import wixHostingAdapter from "@wix/astro-wix-hosting-adapter";
import tailwindcss from "@tailwindcss/vite";
import { siteOrigin } from './src/lib/site.mjs';

// https://astro.build/config
export default defineConfig({
  site: siteOrigin,
  trailingSlash: 'never',
  integrations: [wix(), wixPages()],

  adapter: wixHostingAdapter(),

  image: {
    domains: ["static.wixstatic.com"],
  },

  vite: {
    plugins: [tailwindcss()],
    optimizeDeps: { disabled: true, noDiscovery: true, include: [], exclude: ["aria-query", "axobject-query"] },
    ssr: { external: ["aria-query", "axobject-query"] },
  },

  output: "server",
});
