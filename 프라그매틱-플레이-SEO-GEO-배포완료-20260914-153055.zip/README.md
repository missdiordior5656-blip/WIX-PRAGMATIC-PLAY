# 프라그매틱 플레이 가이드 — SEO/GEO 수정 소스

2026년 9월 13일 GitHub 백업을 바탕으로 9월 14일 SEO/GEO를 수정한 소스입니다. 원본 CMS 스냅샷은 그대로 보존했습니다. 원본 백업의 추출 시각과 개수는 `docs/백업범위.json`, 이번 수정 내용과 적용 방법은 [SEO/GEO 수정 안내](docs/SEO-GEO-수정안내.md)를 참고하세요. 파일에 수정 코드가 있다는 사실만으로 운영 사이트 배포가 완료된 것은 아닙니다.

- [공개 사이트](https://www.alphaxpragmatic.com/)
- [Wix 대시보드](https://manage.wix.com/dashboard/9ff12c75-cafe-4113-a492-e5e5d8d16efe)

## 포함된 내용

- 홈, 회사 소개(`/about`), FAQ(`/faq`), 라이브 카지노(`/live-casino`)의 전체 소스
- 원본 백업 시점의 CMS 콘텐츠 276개와 컬렉션 구조, CSV 사본
- 모든 로컬 이미지와 현재 CMS 이미지의 로컬 사본·대응표
- 원본 백업에 보관된 버튼 문구: 슬롯 4개 **슬롯 플레이하기**, 라이브 10개 **플레이하러 가기**
- 맞춤 도메인 canonical, 페이지별 메타 정보·구조화 데이터, 관련 가이드 링크
- SEO 문구 8개만 갱신하는 계획 파일과 Wix 관리 `llms.txt` 보완 문구
- 편집·복원·SEO/GEO 안내, CMS 비교·복원 및 SEO 검증 스크립트
- 설치 버전을 보관한 `package-lock.json` 및 파일별 SHA-256 목록

버튼 연결 주소도 원본 CMS 스냅샷에 보관되어 있습니다. 이번 SEO 갱신 도구는 링크·이미지·표시 설정을 변경하지 않습니다. 운영 반영 여부는 배포 기록과 검증 결과로 따로 확인합니다.

## GitHub에 보관하기

1. ZIP의 압축을 풉니다.
2. GitHub 저장소에 이 폴더 **안의 파일과 폴더**를 올립니다. 최상위에 `README.md`, `package.json`, `src`, `public`, `cms`가 보이면 됩니다.
3. `.gitignore`도 함께 올립니다. 원본 ZIP을 추가 보관해도 됩니다.

로그인 토큰과 `.env` 파일, `node_modules`, 설치 캐시, 빌드 결과는 포함하지 않았습니다. 이후 개발할 때도 해당 파일은 GitHub에 올리지 않습니다.

## 파일 위치

| 위치 | 내용 |
|---|---|
| `src/` | 페이지, 컴포넌트, 스타일, SEO, CMS 연결 코드 |
| `public/` | 이미지와 사이트 아이콘 |
| `src/data/content.json` | SEO 수정 문구가 반영된 기본 데이터. 이미지 경로는 로컬 사본 사용 |
| `src/lib/site.mjs` | 맞춤 도메인과 네 페이지의 SEO 설정 연결 |
| `cms/PageContent.json` | 9월 13일 원본 CMS 복원용 데이터. Wix 이미지 주소 유지 |
| `cms/PageContent.csv` | 같은 원본 스냅샷의 UTF-8 CSV |
| `cms/seo-content-update.json` | 기존 값 확인 후 SEO 관련 `text` 8개만 갱신하는 변경 계획 |
| `cms/llms-guide-addendum.md` | Wix 관리 `llms.txt`에 덧붙일 독립 가이드 설명 |
| `cms/PageContent.schema.json` | CMS 필드와 권한 설정 |
| `cms/media-manifest.json` | CMS 이미지 주소, 로컬 파일, 원자료 주소, 해시 |
| `docs/편집안내.md` | Wix에서 문구·이미지·링크 수정하기 |
| `docs/복원안내.md` | 설치, CMS 복원, 재배포 순서 |
| `docs/SEO-GEO-수정안내.md` | 수정 범위, 새 제목·설명, 적용·검증 방법과 한계 |
| `scripts/restore-cms.mjs` | 기본 실행은 비교만 수행. `--apply`로 저장된 내용 복원 |
| `scripts/update-seo.mjs` | 기본 실행은 변경 확인만 수행. `--apply`로 좁은 범위의 SEO/GEO 갱신 |
| `scripts/verify-seo.mjs` | 실제 응답의 제목·설명·canonical·구조화 데이터·탐색 파일 검증 |
| `BACKUP-MANIFEST.json` | 백업 파일의 크기와 SHA-256 |

## 다시 실행할 때

Node.js 24 환경에서 작업했습니다. 프로젝트 폴더에서 다음 순서로 진행합니다.

```sh
npm ci --legacy-peer-deps
npx wix login
npx wix env pull
npm run test:seo
npm run build
npm run seo:check
```

`test:seo`는 로컬 코드 검사, `seo:check`는 운영 CMS와 `llms.txt`의 읽기 전용 확인입니다. 검토·빌드가 끝나고 기존 사이트에 실제 반영하려면 다음을 실행합니다.

```sh
npm run seo:apply
npm run release
npm run verify:seo
```

`seo:apply`는 운영 CMS 문구와 `llms.txt`를 수정하고, `release`는 연결된 Wix 사이트의 공개 코드를 갱신합니다. `verify:seo`는 기본적으로 실제 맞춤 도메인을 검사합니다. 이번 SEO 작업에는 전체 CMS 복원이 필요하지 않습니다. 원본 CMS 전체를 복원하면 새 SEO 문구도 원본 값으로 되돌아갈 수 있으므로 [복원 안내](docs/복원안내.md)를 먼저 확인하세요.

Wix Managed Headless/Astro 프로젝트이므로 HTML 파일을 더블클릭하는 방식으로 실행하지 않습니다. Wix 계정 연결과 실행 환경을 다시 준비해야 합니다. 도메인·프리미엄 결제·계정 로그인·검색 도구 소유권은 ZIP에 포함되는 대상이 아니며 기존 계정에서 관리됩니다.
