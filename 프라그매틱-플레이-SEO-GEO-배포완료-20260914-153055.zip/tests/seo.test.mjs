import assert from 'node:assert/strict';
import test from 'node:test';
import { pageSeo } from '../src/lib/seo.ts';
import { canonicalUrl, normalizePagePath, siteOrigin } from '../src/lib/site.mjs';
import { deduplicateSeoHead, seoHeadTransform } from '../src/lib/seo-head.mjs';

const origin = 'https://www.alphaxpragmatic.com';
const baseRows = {
  'seo.siteName': { text: '프라그매틱 플레이 가이드' },
  'seo.title': { text: '회사·게임 정보 | 프라그매틱 플레이 가이드' },
  'seo.description': { text: '홈페이지에서 소개하는 회사와 게임 정보입니다.' },
  'seo.aboutTitle': { text: '회사 소개 | 프라그매틱 플레이 가이드' },
  'seo.aboutDescription': { text: '회사의 역할과 기술을 설명합니다.' },
  'seo.faqTitle': { text: '자주 묻는 질문 | 프라그매틱 플레이 가이드' },
  'seo.faqDescription': { text: '회사와 게임에 대한 질문에 답합니다.' },
  'seo.liveTitle': { text: '라이브 카지노 | 프라그매틱 플레이 가이드' },
  'seo.liveDescription': { text: '라이브 카지노의 게임과 화면을 소개합니다.' },
  'footer.description': { text: '공식 제작사와 구분되는 독립 정보 가이드입니다.' },
  'hero.image': { image: '/images/home.jpg', text: '홈페이지 게임 이미지' },
  'aboutpage.image': { image: '/images/about.jpg', text: '회사 소개 이미지' },
  'livepage.hero.image': { image: 'https://static.wixstatic.com/media/live.jpg', text: '라이브 게임 이미지' },
  'brand.favicon': { image: '/guide-icon.svg' },
  'source.company': { text: '공식 회사 소개', href: 'https://www.pragmaticplay.com/en/about-us/' },
  'source.games': { text: '공식 게임 자료', href: 'https://www.pragmaticplay.com/en/games/' },
  'source.live': { text: '공식 라이브 자료', href: 'https://www.pragmaticplay.com/en/live-casino/' },
  'faq.1.question': { text: '어떤 회사인가요?' },
  'faq.1.answer': { text: '게임 콘텐츠를 개발하는 회사입니다.' },
  'faq.2.question': { text: '공식 사이트인가요?' },
  'faq.2.answer': { text: '독립 가이드입니다.' },
  'livepage.faq.1.question': { text: '슬롯과 라이브 게임의 차이는?' },
  'livepage.faq.1.answer': { text: '진행 방식과 화면 구성이 다릅니다.' },
};

// Model the already-filtered PageContent interface without importing Wix SDKs.
function content(rows = baseRows) {
  const visibleRow = key => rows[key]?.visible === false ? undefined : rows[key];
  return {
    text: key => visibleRow(key)?.text ?? '',
    image: key => visibleRow(key)?.image ?? '',
    link: key => {
      const row = visibleRow(key);
      return row?.text && row.href ? row : undefined;
    },
  };
}

function graphOf(seo) {
  const data = JSON.parse(seo.jsonLd);
  assert.equal(data['@context'], 'https://schema.org');
  return data['@graph'];
}

const cases = [
  { path: '/', title: '회사·게임 정보 | 프라그매틱 플레이 가이드', description: '홈페이지에서 소개하는 회사와 게임 정보입니다.', image: `${origin}/images/home.jpg`, alt: '홈페이지 게임 이미지', type: 'CollectionPage' },
  { path: '/about', title: '회사 소개 | 프라그매틱 플레이 가이드', description: '회사의 역할과 기술을 설명합니다.', image: `${origin}/images/about.jpg`, alt: '회사 소개 이미지', type: 'AboutPage' },
  { path: '/faq', title: '자주 묻는 질문 | 프라그매틱 플레이 가이드', description: '회사와 게임에 대한 질문에 답합니다.', image: `${origin}/images/home.jpg`, alt: '홈페이지 게임 이미지', type: 'FAQPage' },
  { path: '/live-casino', title: '라이브 카지노 | 프라그매틱 플레이 가이드', description: '라이브 카지노의 게임과 화면을 소개합니다.', image: 'https://static.wixstatic.com/media/live.jpg', alt: '라이브 게임 이미지', type: 'WebPage' },
];

for (const expected of cases) {
  test(`${expected.path}: canonical and social metadata use the production domain and matching page content`, () => {
    const seo = pageSeo(content(), expected.path);
    assert.equal(siteOrigin, origin);
    assert.equal(seo.canonical, `${origin}${expected.path}`);
    assert.equal(seo.title, expected.title);
    assert.equal(seo.description, expected.description);
    assert.equal(seo.siteName, '프라그매틱 플레이 가이드');
    assert.equal(seo.image, expected.image);
    assert.equal(seo.imageAlt, expected.alt);
    assert.equal(seo.icon, '/guide-icon.svg');
    assert.deepEqual(pageSeo(content(), `${expected.path}/`), seo);

    const graph = graphOf(seo);
    const ids = graph.map(node => node['@id']);
    assert.equal(new Set(ids).size, ids.length, 'schema node IDs must be unique');
    const website = graph.find(node => node['@type'] === 'WebSite');
    assert.equal(website['@id'], `${origin}/#website`);
    assert.equal(website.url, `${origin}/`);
    assert.equal(website.name, seo.siteName);
    assert.equal(website.description, baseRows['footer.description'].text);
    const page = graph.find(node => node['@id'] === `${seo.canonical}#webpage`);
    assert.equal(page['@type'], expected.type);
    assert.equal(page.url, seo.canonical);
    assert.equal(page.name, expected.title);
    assert.equal(page.description, expected.description);
    assert.equal(page.inLanguage, 'ko');
    assert.deepEqual(page.isPartOf, { '@id': website['@id'] });
    assert.deepEqual(page.citation, [
      'https://www.pragmaticplay.com/en/about-us/',
      'https://www.pragmaticplay.com/en/games/',
      'https://www.pragmaticplay.com/en/live-casino/',
    ]);
    const primaryImage = graph.find(node => node['@id'] === page.primaryImageOfPage['@id']);
    assert.equal(primaryImage['@type'], 'ImageObject');
    assert.equal(primaryImage.contentUrl, expected.image);
    assert.equal(primaryImage.caption, expected.alt);

    const breadcrumb = graph.find(node => node['@type'] === 'BreadcrumbList');
    if (expected.path === '/') {
      assert.equal(breadcrumb, undefined);
      assert.equal(page.breadcrumb, undefined);
    } else {
      assert.deepEqual(page.breadcrumb, { '@id': `${seo.canonical}#breadcrumb` });
      assert.equal(breadcrumb['@id'], page.breadcrumb['@id']);
      assert.deepEqual(breadcrumb.itemListElement.map(item => [item.position, item.item]), [
        [1, `${origin}/`], [2, seo.canonical],
      ]);
      assert.equal(breadcrumb.itemListElement[0].name, seo.siteName);
      assert(breadcrumb.itemListElement[1].name);
    }
  });
}

test('canonical path normalization rejects unsupported pages and external URLs', () => {
  assert.equal(normalizePagePath('/about///'), '/about');
  assert.equal(canonicalUrl('/about///'), `${origin}/about`);
  assert.equal(canonicalUrl('/'), `${origin}/`);
  assert.equal(canonicalUrl('///'), `${origin}/`);
  for (const path of ['/unknown', '/about?campaign=x', 'https://other.example/about', '//other.example/about']) {
    assert.throws(() => canonicalUrl(path), /Unknown guide page/);
  }
});

test('FAQ schema contains only complete, visible question/answer pairs and links to its page', () => {
  const rows = {
    ...baseRows,
    'faq.2.answer': { text: '숨긴 답변', visible: false },
    'faq.3.question': { text: '답변이 없는 질문' },
    'faq.4.answer': { text: '질문이 없는 답변' },
    'faq.5.question': { text: '마지막 질문' },
    'faq.5.answer': { text: '마지막 답변' },
    'livepage.faq.2.question': { text: '숨긴 질문', visible: false },
    'livepage.faq.2.answer': { text: '숨긴 질문의 답변' },
    'livepage.faq.3.question': { text: '답변이 없는 라이브 질문' },
  };
  const c = content(rows);
  const faq = graphOf(pageSeo(c, '/faq')).find(node => node['@type'] === 'FAQPage');
  assert.equal(faq['@id'], `${origin}/faq#webpage`);
  assert.deepEqual(faq.mainEntity, [1, 5].map(i => ({
    '@type': 'Question', name: c.text(`faq.${i}.question`),
    acceptedAnswer: { '@type': 'Answer', text: c.text(`faq.${i}.answer`) },
  })));
  const liveGraph = graphOf(pageSeo(c, '/live-casino'));
  const livePage = liveGraph.find(node => node['@id'] === `${origin}/live-casino#webpage`);
  const liveFaq = liveGraph.find(node => node['@type'] === 'FAQPage');
  assert.deepEqual(livePage.hasPart, { '@id': liveFaq['@id'] });
  assert.deepEqual(liveFaq.isPartOf, { '@id': livePage['@id'] });
  assert.deepEqual(liveFaq.mainEntity, [{
    '@type': 'Question', name: c.text('livepage.faq.1.question'),
    acceptedAnswer: { '@type': 'Answer', text: c.text('livepage.faq.1.answer') },
  }]);
});

test('removed CMS metadata, images, references and FAQ stay removed instead of using backup content', () => {
  const c = content({});
  for (const { path } of cases) {
    const seo = pageSeo(c, path);
    for (const key of ['title', 'description', 'siteName', 'image', 'imageAlt', 'icon']) {
      assert.equal(seo[key], '', `${path}: ${key} must remain empty`);
    }
    const graph = graphOf(seo);
    assert.equal(graph.some(node => node['@type'] === 'FAQPage'), false);
    assert.equal(graph.some(node => node['@type'] === 'ImageObject'), false);
    const page = graph.find(node => node['@id'] === `${seo.canonical}#webpage`);
    assert.equal(page.mainEntity, undefined);
    assert.equal(page.hasPart, undefined);
    assert.equal(page.citation, undefined);
  }
});

test('JSON-LD escapes closing script markup while retaining the exact CMS value after parsing', () => {
  const malicious = '</script><script>alert("CMS")</script><img src=x>';
  const c = content({
    ...baseRows,
    'seo.faqTitle': { text: malicious },
    'faq.1.answer': { text: malicious },
  });
  const seo = pageSeo(c, '/faq');
  assert.equal(seo.jsonLd.includes('<'), false);
  assert(seo.jsonLd.includes('\\u003c/script>'));
  const faq = graphOf(seo).find(node => node['@type'] === 'FAQPage');
  assert.equal(faq.name, malicious);
  assert.equal(faq.mainEntity[0].acceptedAnswer.text, malicious);
});

const preservedHead = [
  '<meta wix-seo-tag="true" name="google-site-verification" content="verification-value">',
  '<meta wix-seo-tag="true" name="robots" content="noindex, nofollow">',
  '<script wix-seo-tag="true" type="application/ld+json">{"@type":"WebSite","name":"Wix"}</script>',
  '<script src="https://example.com/integration.js" defer></script>',
  '<link rel="stylesheet" href="/styles/site.css">',
].join('');
const authoredHead = [
  '<title data-site-seo>작성한 제목</title>',
  '<meta data-site-seo name="description" content="작성한 설명">',
  `<link data-site-seo rel="canonical" href="${origin}/">`,
  `<meta data-site-seo property="og:url" content="${origin}/">`,
].join('');
const duplicateHead = [
  '<title wix-seo-tag="true">기존 제목</title>',
  '<meta content="기존 설명" name="description" wix-seo-tag="true">',
  '<link wix-seo-tag="true" href="https://old.example/" rel="canonical">',
  "<meta property='og:url' content='https://old.example/' wix-seo-tag='true'>",
].join('');
const inputHead = `<head>${duplicateHead}${preservedHead}${authoredHead}</head>`;
const expectedHead = `<head>${preservedHead}${authoredHead}</head>`;

test('head deduplication removes matching Wix metadata and preserves verification, noindex and unrelated scripts', () => {
  assert.equal(deduplicateSeoHead(inputHead), expectedHead);
  assert.equal(deduplicateSeoHead(expectedHead), expectedHead, 'deduplication is idempotent');
  assert.equal(deduplicateSeoHead(`<head>${duplicateHead}</head>`), `<head>${duplicateHead}</head>`,
    'Wix metadata without an authored replacement must remain');
});

async function transformChunks(input, size) {
  const chunks = new ReadableStream({
    start(controller) {
      for (let i = 0; i < input.length; i += size) controller.enqueue(input.slice(i, i + size));
      controller.close();
    },
  });
  let output = '';
  for await (const chunk of chunks.pipeThrough(seoHeadTransform())) output += chunk;
  return output;
}

test('streamed head transformation handles split tags without touching body content', async () => {
  const body = '<body><h1>본문</h1><template><title wix-seo-tag="true">템플릿 제목</title></template></body>';
  const input = `<!doctype html><html lang="ko">${inputHead}${body}</html>`;
  const expected = `<!doctype html><html lang="ko">${expectedHead}${body}</html>`;
  for (const size of [1, 7, 37, 128, 4096]) {
    assert.equal(await transformChunks(input, size), expected, `chunk size ${size}`);
  }
  assert.equal(await transformChunks('<html><body>head 없는 응답</body></html>', 7),
    '<html><body>head 없는 응답</body></html>');
});
